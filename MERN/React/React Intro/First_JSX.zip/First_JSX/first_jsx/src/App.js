import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <h1>Hello Dojo!</h1>
      <h3>To do list:</h3>
        <ul>
          <li>Finish Mern</li>
          <li>Camping</li>
          <li>Move Back to SD</li>
          <li>Apply for Jobs</li>
        </ul>
    </div>
  );
}

export default App;
