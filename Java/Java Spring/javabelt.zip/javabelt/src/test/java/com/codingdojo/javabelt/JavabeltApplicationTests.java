package com.codingdojo.javabelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavabeltApplicationTests {

	@Test
	void contextLoads() {
	}

}
