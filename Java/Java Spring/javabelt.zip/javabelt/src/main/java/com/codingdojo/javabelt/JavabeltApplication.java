package com.codingdojo.javabelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavabeltApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavabeltApplication.class, args);
	}

}
