package com.codingdojo.edittravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullCrudSaveTravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullCrudSaveTravelsApplication.class, args);
	}

}
