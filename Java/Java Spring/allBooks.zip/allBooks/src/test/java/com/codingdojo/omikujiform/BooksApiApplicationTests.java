package com.codingdojo.omikujiform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
