package com.codingdojo.renderingbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RenderingBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(RenderingBooksApplication.class, args);
	}

}
